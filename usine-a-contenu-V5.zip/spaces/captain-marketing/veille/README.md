# Veille — Captain Marketing

Ranger ici tous les digests de veille produits par le skill `watch`.

Format du nom de fichier recommandé : `YYYY-MM-DD-nom-source.md`
