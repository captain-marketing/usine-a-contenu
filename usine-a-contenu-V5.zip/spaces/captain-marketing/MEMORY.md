# Mémoire — Captain Marketing

_Dernière mise à jour : 2026-04-06_

## Idées validées en attente de production

## Contenus produits
<!-- Titre | Format | Date | Statut -->
Newsletter en 2026 : 6 leviers concrets pour la faire grandir | Article de blog | 2026-04-06 | Draft Ghost — en attente de publication

## Sujets déjà traités
- Newsletter en 2026 : état de l'art, leviers de croissance, réseaux de recommandation, YouTube/Instagram vers email, collaborations éditoriales

## Idées refusées

## Notes et retours
