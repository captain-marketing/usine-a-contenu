# Stratégie — Captain Marketing

Ranger ici tous les livrables stratégiques : audits, analyses concurrentielles, personas, plans éditoriaux.

Format du nom de fichier recommandé : `YYYY-MM-DD-type-livrable.md`
