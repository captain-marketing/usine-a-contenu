# Captain Marketing — Profil éditorial

## Description
Blog Ghost et newsletter SYSTEMIA sur le marketing digital, l'IA marketing et la génération de leads B2B.

## Audience cible
Freelances, entrepreneurs, PME/ETI et responsables marketing qui veulent utiliser l'IA pour booster leur marketing et générer des leads.

## Formats prioritaires
- Article de blog (Ghost CMS — blog.captainmarketing.io)
- Newsletter (SYSTEMIA)
- Post LinkedIn
- Script YouTube (courts et longs)
- Tweets / Threads X

## Ton éditorial
Pédagogique et accessible. On explique les concepts complexes simplement, avec des exemples concrets. Expert sans être condescendant. Tutoiement naturel, conversationnel mais professionnel.

## Mots-clés SEO prioritaires
À définir

## Sources de référence et concurrents
Aucun défini — à compléter dans sources.md

## Contraintes
- Ne jamais utiliser le tiret cadratin (—). Le remplacer par une virgule ou reformuler la phrase.
- Pas d'hyperboles ni de formules creuses : jamais "révolutionnaire", "game-changer", "incroyable opportunité"
- Pas de listes à puces excessives qui ressemblent à du ChatGPT générique
- Pas d'introductions vagues du type "Dans le monde du marketing digital..."
- Pas de promesses exagérées sans preuves
- Ton jamais condescendant ni moralisateur
- Éviter les emphases excessives et le jargon inutile
- Utiliser "actionnable" plutôt que "applicable", "méthode/système/framework" plutôt que "hack"

## Instructions
Lire ce fichier avant toute production.
Lire `style-card.md` pour appliquer précisément les patterns d'écriture de Stéphane.
Consulter MEMORY.md pour éviter les doublons.
Se référer au skill `style-captain-marketing` pour les règles d'écriture complémentaires.
