# Sources de veille — Captain Marketing

_Dernière mise à jour : 2026-04-06_

## Sources actives

| Source | URL | Type | Fréquence | Dernière veille |
|--------|-----|------|-----------|-----------------|
| Sunny Lenarduzzi | https://www.youtube.com/@SunnyLenarduzzi | YouTube | Hebdo | — |
| Daniel Priestley | https://www.youtube.com/@DanielPriestley | YouTube | Hebdo | — |
| Build In Public | https://www.youtube.com/@buildinpublic | YouTube | Hebdo | — |
| Iman Gadzhi | https://www.youtube.com/@ImanGadzhi | YouTube | Hebdo | — |
| Henri ExplorIA | https://www.youtube.com/@HenriExplorIA | YouTube | Hebdo | — |
| MATGpod | https://www.youtube.com/@MATGpod | YouTube | Hebdo | — |
| Grace Leung | https://www.youtube.com/@graceleungyl | YouTube | Hebdo | — |
| Alex Hormozi | https://www.youtube.com/@AlexHormozi | YouTube | Hebdo | — |
| Marketing Ideas | https://www.marketingideas.com/ | Blog / Newsletter | Hebdo | — |
| SparkToro Blog | https://sparktoro.com/blog/ | Blog | Hebdo | — |
| Frontera Brands | https://fronterabrands.com/best-articles/ | Blog | Hebdo | — |
| Digital Native | https://www.digitalnative.tech/ | Newsletter | Hebdo | — |
| Growth in Reverse | https://growthinreverse.com/archive/ | Newsletter | Hebdo | — |
| Génération IA (Flint) | https://generationia.flint.media/ | Newsletter | Hebdo | — |
| Ghost Resources Newsletter | https://ghost.org/resources/newsletter/ | Blog / Newsletter | Hebdo | — |

## Sources à explorer

## Mots-clés de veille Google

## Chaînes YouTube à surveiller
