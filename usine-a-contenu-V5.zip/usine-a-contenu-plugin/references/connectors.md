# Connecteurs — Référence d'extension du plugin

Ce fichier référence tous les connecteurs MCP disponibles ou planifiés pour l'Usine à Contenu.
Les skills lisent ce fichier pour adapter leur comportement selon les connecteurs actifs.

---

## Connecteurs actifs par défaut

Ces connecteurs sont détectés automatiquement par les skills `publisher` et `strategy` :

| Connecteur | Plateforme | Skills concernés | Statut |
|---|---|---|---|
| `typefully` | X, LinkedIn, Instagram | publisher | Officiel |
| `wordpress` | WordPress | publisher | Officiel |
| `ghost` | Ghost CMS | publisher, ghost-seo | Communautaire |
| `google-analytics` | GA4 | strategy, audit | Officiel |
| `google-search-console` | GSC | strategy, audit | Officiel |
| `google-sheets` | Google Sheets | strategy | Officiel |

---

## Connecteurs d'enrichissement SEO

Ces connecteurs enrichissent les skills `research`, `optimize`, `ideation` et `audit` avec des données SEO externes.

| Connecteur | Fournisseur | Skills concernés | Statut |
|---|---|---|---|
| `dataseo` | DataSEO API | research, optimize, ideation, audit | Planifié — voir config ci-dessous |
| `semrush` | SEMrush API | research, audit | Planifié |
| `ahrefs` | Ahrefs API | audit | Planifié |

### Configuration DataSEO

Pour activer DataSEO dans les skills compatibles :

1. Ajoute le connecteur dans `.mcp.json` de l'espace :
```json
{
  "mcpServers": {
    "dataseo": {
      "type": "http",
      "url": "https://api.dataforseo.com/v3/",
      "headers": {
        "Authorization": "Basic [TON_TOKEN_BASE64]"
      }
    }
  }
}
```

2. Une fois configuré, les skills `research` et `optimize` activent automatiquement les appels DataSEO pour :
   - Volume de recherche et difficulté des mots-clés
   - SERP features présentes sur les requêtes cibles
   - Suggestions de mots-clés longue traîne
   - Analyse des Featured Snippets

**Skills qui s'adaptent si DataSEO est connecté :**

#### Dans `research`
```
[Si DataSEO connecté]
Enrichit la synthèse avec :
- Volume mensuel estimé pour les requêtes identifiées
- Keyword Difficulty (KD)
- Top 3 résultats SERP pour chaque requête
```

#### Dans `optimize`
```
[Si DataSEO connecté]
Enrichit l'audit SEO avec :
- Position actuelle du contenu (si URL fournie)
- Mots-clés sémantiquement proches à intégrer
- Comparaison longueur contenu vs top 3 SERP
```

#### Dans `ideation`
```
[Si DataSEO connecté]
Ajoute pour chaque idée :
- Volume de recherche estimé
- KD estimé
- Potentiel SEO : faible / moyen / fort
```

#### Dans `audit`
```
[Si DataSEO connecté]
Remplace les estimations manuelles par des données réelles :
- Volume réel des requêtes non couvertes
- Position moyenne par page (si URLs fournies)
```

---

## Ajouter un connecteur personnalisé

Pour intégrer un nouveau connecteur :

1. Ajoute une entrée dans ce fichier sous la section correspondante
2. Définis les skills impactés et le comportement conditionnel attendu
3. Ajoute la configuration MCP dans `.mcp.json`
4. Mets à jour les skills concernés avec le bloc conditionnel `[Si [connecteur] connecté]`

**Convention de nommage des blocs conditionnels dans les skills :**
```
[Si [nom-connecteur] connecté]
[comportement enrichi]

[Si [nom-connecteur] absent]
[comportement par défaut / fallback]
```
