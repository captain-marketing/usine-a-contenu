---
name: review
description: Relire un contenu produit et vérifier sa conformité avec le profil éditorial de l'espace (ton, style, interdits, structure). Produit un rapport de relecture avec corrections suggérées. Se déclenche sur "relis ce contenu", "vérifie que c'est conforme", "relecture", "est-ce que c'est dans le bon ton ?", ou en enchaînement après produce.
---

# Skill — Review (Agent Relecteur)

Relit un contenu produit et vérifie sa conformité avec le profil éditorial de l'espace actif.

---

## Étape 1 — Charger les références

Lis dans l'ordre :
1. `CLAUDE.md` de l'espace actif — contraintes, ton, interdits explicites
2. `style-card.md` de l'espace actif si elle existe — patterns précis, vocabulaire, interdits rhétoriques
3. `references/formats.md` — specs structurelles du format concerné

**Si `style-card.md` est absent :** appliquer uniquement `CLAUDE.md` et signaler l'absence.

---

## Étape 2 — Identifier le contenu à relire

- Contenu produit dans la session en cours (priorité)
- Sinon : demander à l'utilisateur de coller le contenu ou préciser le fichier

---

## Étape 3 — Grille de relecture

Évalue le contenu sur ces 6 axes, avec un statut ✅ / ⚠️ / ❌ pour chacun :

### A — Conformité stylistique
- Interdits présents ? (tiret cadratin, hyperboles, formules interdites listées dans CLAUDE.md ou style-card.md)
- Patterns à éviter respectés ? (structure "Ce n'est pas X. C'est Y.", staccato nominal, etc.)
- Vocabulaire : termes proscrits utilisés ? termes recommandés absents ?

### B — Ton et registre
- Tutoiement constant si l'espace l'exige ?
- Registre conforme à l'espace (expert accessible, pédagogique, etc.) ?
- Aucune condescendance, aucun moralisme ?

### C — Structure et format
- Respect des specs de longueur (`references/formats.md`) ?
- Structure attendue présente (H1, sections, conclusion) ?
- Pas d'introduction vague ?
- Listes à puces justifiées (pas systématiques) ?

### D — Valeur et concrétisation
- Chaque point abstrait est-il illustré par un exemple concret ou un chiffre ?
- La conclusion propose-t-elle une action ou un prompt ?
- Pas de promesses sans preuves ?

### E — Cohérence avec l'espace
- Le sujet ne duplique pas un contenu déjà traité (vérifier MEMORY.md) ?
- Mots-clés SEO intégrés naturellement si définis dans CLAUDE.md ?

### F — Patterns d'écriture (si style-card.md disponible)
- Hook conforme aux patterns d'accroche de la style-card ?
- Conclusion conforme aux patterns de conclusion ?
- Syntaxe respectée (longueur des phrases, ponctuation, gras fonctionnel) ?

---

## Étape 4 — Rapport de relecture

```markdown
## Rapport de relecture — [Titre du contenu]
Espace : [nom] | Date : [date] | Style Card : [présente / absente]

### Résumé
[1-2 phrases : état général du contenu]

### A — Conformité stylistique : [✅ / ⚠️ / ❌]
[Observations + extraits problématiques entre guillemets si nécessaire]

### B — Ton et registre : [✅ / ⚠️ / ❌]
[Observations]

### C — Structure et format : [✅ / ⚠️ / ❌]
[Observations]

### D — Valeur et concrétisation : [✅ / ⚠️ / ❌]
[Observations]

### E — Cohérence avec l'espace : [✅ / ⚠️ / ❌]
[Observations]

### F — Patterns d'écriture : [✅ / ⚠️ / ❌ / N/A si style-card absente]
[Observations]

### Points à corriger
1. [Point critique — priorité haute]
2. [Point à améliorer]
3. [Suggestion mineure]

### Points forts
[Ce qui fonctionne bien — 2-3 points]
```

---

## Étape 5 — Proposition de correction

Après le rapport, propose :

> "Tu veux que je corrige directement les points identifiés et que je produise la version corrigée ?"

AskUserQuestion :
- ✅ Oui, corrige et donne-moi la version finale
- 📋 Non, je vais corriger moi-même avec tes notes
- 🔍 Corrige uniquement les points critiques

Si l'utilisateur demande la correction, produit la version corrigée **en intégralité** (pas de diff partiel), puis sauvegarde dans le même dossier de destination avec le suffixe `-v2`.
