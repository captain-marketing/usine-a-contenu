---
name: produce
description: Produire un contenu complet à partir d'une idée validée. Applique le profil éditorial de l'espace actif. Supporte tous les formats. Se déclenche uniquement après validation explicite d'une idée, sur "rédige [format] sur [sujet]", "écris un article sur [sujet]", ou après un "go pour le n°X" en sortie de ideation.
---

# Skill — Produce

---

## Étape 1 — Contexte

Lis dans l'ordre :
1. `CLAUDE.md` de l'espace actif — ton éditorial, audience, contraintes, mots-clés SEO
2. `style-card.md` de l'espace actif si elle existe — patterns d'écriture précis, hooks, vocabulaire, interdits
3. `references/formats.md` — specs structurelles du format demandé (longueur, structure, enchaînements)
4. `MEMORY.md` — sujets déjà traités à ne pas dupliquer

**Ordre de priorité stylistique :**
- `style-card.md` > `CLAUDE.md` > `references/formats.md`
- Si `style-card.md` absent : appliquer `CLAUDE.md` seul.
- `formats.md` ne couvre que la structure et la longueur — jamais le ton ni les interdits.

---

## Étape 2 — Produire

Applique les specs du format et le profil éditorial de l'espace.

Règles : ton éditorial de l'espace (pas générique), mots-clés intégrés naturellement, valeur concrète, pas d'introduction vague, angle clair.

---

## Étape 3 — Sauvegarder dans le bon dossier

Après la production, sauvegarde le fichier dans le sous-dossier correspondant au format produit :

| Format produit | Dossier de destination |
|---|---|
| Article de blog | `spaces/[espace]/articles/` |
| Newsletter | `spaces/[espace]/newsletters/` |
| Post LinkedIn | `spaces/[espace]/linkedin/` |
| Tweet / Thread X | `spaces/[espace]/x/` |
| Post Instagram | `spaces/[espace]/instagram/` |
| Script YouTube court | `spaces/[espace]/scripts-video/courts/` |
| Script YouTube long | `spaces/[espace]/scripts-video/longs/` |

**Nom de fichier recommandé :** `YYYY-MM-DD-titre-court.md`

Si le dossier n'existe pas encore, le créer avec un `README.md` minimal.

> Confirme à l'utilisateur : "✅ Contenu sauvegardé dans `spaces/[espace]/[dossier]/[nom-fichier].md`"

---

## Étape 4 — Enchaînements proposés

Après la production :
> "Tu veux que j'optimise ce contenu pour le SEO et le GEO ?"
→ Si oui, active `optimize`

> "Tu veux que je génère les métadonnées Ghost pour cet article ?"
→ Si oui, active `ghost-seo`

> "Tu veux que je le relise pour vérifier que tout est bien conforme au profil éditorial ?"
→ Si oui, active `review`

> "Tu veux publier ce contenu sur une plateforme ?"
→ Si oui, active `publisher`

---

## Étape 5 — Tracker & MEMORY.md

Mets automatiquement à jour le tracker de l'espace actif (`content-tracker.json`) :
- Si le sujet était dans `idées` : retire l'entrée correspondante
- Ajoute une entrée dans `contenus` avec `statut: "prêt"` et la date du jour

Puis demande :
> "Je note ce contenu dans la mémoire de l'espace ?"

Si oui, ajoute dans `MEMORY.md` :
```
[Titre] | [Format] | [Date] | Produit — en attente de publication
```
