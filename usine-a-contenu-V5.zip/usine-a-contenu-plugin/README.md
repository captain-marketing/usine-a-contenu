# Usine à Contenu — Plugin Cowork V5

**Auteur :** Stéphane Truphème — Captain Marketing (captainmarketing.io)
**Version :** 5.0.0

Plugin de production de contenu multi-format pour Claude Cowork. Fonctionne en trois modules indépendants.

---

## Modules

### 📋 Module Stratégie
Audit de contenus existants, analyse concurrentielle, création de personas, plan éditorial 3-12 mois.
Commande : `/usine-a-contenu:strategy`

### ⚙️ Module Production
Recherche, veille, idéation, rédaction, optimisation SEO/GEO, relecture, métadonnées Ghost.
Les skills se déclenchent automatiquement selon le contexte.

### 📤 Module Publication
Publication et scheduling vers WordPress, X, LinkedIn, Instagram, Ghost.
Commande : `/usine-a-contenu:publish`

---

## Skills disponibles

| Skill | Rôle | Déclencheur |
|---|---|---|
| `begin` | Initialisation du plugin | `begin`, premier lancement |
| `new-space` | Créer un espace de travail | `new-space`, `nouveau client` |
| `research` | Recherche Google + YouTube | `cherche ce qui se fait sur [sujet]` |
| `watch` | Veille de sources | `surveille [source]` |
| `ideation` | Idées de contenus | `propose des idées sur [thème]` |
| `produce` | Rédaction complète | `rédige [format] sur [sujet]` |
| `review` | Relecture éditoriale | `relis ce contenu`, `relecture` |
| `optimize` | SEO + GEO | `optimise ce contenu` |
| `ghost-seo` | Métadonnées Ghost CMS | `génère les métadonnées Ghost` |
| `publisher` | Publication vers plateformes | `/usine-a-contenu:publish` |
| `tracker` | Suivi des contenus | `Où en sommes nous ?` |
| `strategy` | Module stratégie complet | `/usine-a-contenu:strategy` |
| `audit` | Audit de contenus | `audite mon site` |
| `competitive` | Analyse concurrentielle | `analyse mes concurrents` |
| `persona-builder` | Création de personas | `crée un persona` |

---

## Structure d'un espace de travail

```
spaces/[identifiant]/
├── CLAUDE.md              — profil éditorial de l'espace
├── MEMORY.md              — mémoire des contenus produits
├── style-card.md          — patterns d'écriture (généré par analyseur-style-editorial)
├── sources.md             — sources de veille planifiée
├── content-tracker.json   — tracker des contenus (idées → publiés)
├── articles/              — articles de blog
├── newsletters/           — newsletters
├── linkedin/              — posts LinkedIn
├── x/                     — tweets et threads
├── instagram/             — posts Instagram
├── scripts-video/
│   ├── courts/            — scripts YouTube < 60s
│   └── longs/             — scripts YouTube > 5 min
├── assets/                — images et visuels
├── veille/                — digests de veille (skill watch)
└── strategie/             — livrables stratégiques (audits, personas, plans)
```

---

## Connecteurs MCP

Voir `references/connectors.md` pour la liste complète des connecteurs supportés et les instructions d'ajout.

**Connecteurs natifs :** Typefully, WordPress, Ghost, GA4, GSC, Google Sheets
**Connecteurs SEO enrichis (optionnels) :** DataSEO, SEMrush, Ahrefs

---

## Fichiers de référence

| Fichier | Contenu |
|---|---|
| `references/formats.md` | Specs structurelles des formats (longueur, structure) |
| `references/platforms.md` | Règles de compatibilité format/plateforme |
| `references/seo-geo.md` | Règles SEO et GEO |
| `references/connectors.md` | Architecture des connecteurs MCP extensibles |
| `references/persona-methods.md` | Méthodes de construction de personas |
| `references/persona-template.md` | Template fiche persona |

---

## Changelog

### V5.0.0
- **Fusion publish/publisher** — un seul skill `publisher`, `publish` supprimé
- **Autorité du style** — `produce` lit désormais `style-card.md` > `CLAUDE.md` > `formats.md` dans l'ordre de priorité
- **Classification automatique** — `produce` sauvegarde dans le bon sous-dossier selon le format
- **Nouveaux dossiers** — `veille/` et `strategie/` créés systématiquement à chaque `new-space`
- **Connecteurs extensibles** — `references/connectors.md` centralise l'architecture, DataSEO préconfiguré
- **Skill `review`** — agent relecteur sur 6 axes avec rapport structuré et version corrigée

### V4.0.0
- Tracker de contenus JSON intégré
- Skill ghost-seo
- Module stratégie complet (audit, competitive, personas, plan éditorial)
